<?php
/**
 *	Aurum WordPress Theme
 *
 *	Laborator.co
 *	www.laborator.co
 */

?>

	<?php if( ! defined("LAB_FOOTERLESS")) get_template_part('tpls/footer'); ?>

	<?php wp_footer(); ?>

</body>
</html>
