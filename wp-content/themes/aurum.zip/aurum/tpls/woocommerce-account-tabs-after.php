<?php
/**
 *	Aurum WordPress Theme
 *
 *	Laborator.co
 *	www.laborator.co
 */

?>
		</div>
	</div>
</div>

<?php do_action( 'woocommerce_after_my_account' ); ?>