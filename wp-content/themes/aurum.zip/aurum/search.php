<?php
/**
 *	Aurum WordPress Theme
 *
 *	Laborator.co
 *	www.laborator.co
 */

get_header();

get_template_part('tpls/search-results');

get_footer();