<?php
/*
	Template Name: Contact Us
*/

/**
 *	Aurum WordPress Theme
 *
 *	Laborator.co
 *	www.laborator.co
 */

wp_enqueue_script('aurum-contact');

get_header();

get_template_part('tpls/contact');

get_footer();