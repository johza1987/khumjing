Customer Conversion Tracker by Ecommerce Tools
-----------------------------------


Description:- Customer Conversion Tracker plugin is used to give insight into customers’ checkout experience. It allows you to view the flow of customers through your stores checkout system enabling you to identify any weak areas where customers are getting stuck or abandoning their purchase. 

How To Use :-

1.To use this plugin firstly you need to activate "Woocommerce" plugin.

2.After this activate "Customer Conversion Tracker" Plugin.

3.After after both plugins have been activated the dashboard widget and the tracker graph in the sidebar should appear. 

4.To export customer conversion data go into the tracker graph from the WP sidebar and choose ‘export CSV’ in the top right after choosing a custom date period in the top left.   

see Attachment:-"Customer_Conversion_Tracker_Widget.png" and "Customer_Conversion_Tracker_Graph.png"